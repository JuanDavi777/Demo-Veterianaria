﻿using BLL;
using ENTITY;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUI
{
    public class VistaVeterinario
    {
        ServicioVeterinario servicio = new ServicioVeterinario();

        public void Menu()
        {
            int op;

            do
            {
                Console.Clear();
                Console.SetCursorPosition(10, 5); Console.WriteLine("GESTION DE VETERINARIOS");

                Console.SetCursorPosition(10, 8); Console.WriteLine("1. Agregar Nuevo Veterinario");
                Console.SetCursorPosition(10, 9); Console.WriteLine("2. Consulta General de Veterinario");
                Console.SetCursorPosition(10, 11); Console.WriteLine("0. Salir");

                Console.SetCursorPosition(10, 13); Console.WriteLine("Digite una opcion");
                Console.SetCursorPosition(29, 13); op = int.Parse(Console.ReadLine());

                switch (op)
                {
                    case 1:
                        Agregar();
                        break;
                    case 2:
                        Consultar();
                        break;

                }

            } while (op != 0);
        }

        private void Consultar()
        {
            Console.Clear();
            var ListaVeterinarios = servicio.Consultar();
            Console.SetCursorPosition(10, 5); Console.WriteLine("CONSULTA DE VETERINARIOS");

            int fila = 10;
            Console.SetCursorPosition(10, 8); Console.WriteLine(" ID              NOMBRES         TELEFONOS");
            Console.SetCursorPosition(10, 9); Console.WriteLine("--------------------------------------------");
            foreach (var buscar in ListaVeterinarios)
            {   
                Console.SetCursorPosition(11, fila); Console.Write(buscar.Id);
                Console.SetCursorPosition(27, fila); Console.Write(buscar.Nombres);
                Console.SetCursorPosition(43, fila); Console.WriteLine(buscar.telefono);
                
                fila ++;
            }
            Console.SetCursorPosition(10, fila); Console.WriteLine("--------------------------------------------");
            Console.ReadKey();
        }

        private void Agregar()
        {
            Veterinario veterinario = new Veterinario();
            Console.Clear();
            Console.SetCursorPosition(10, 5); Console.WriteLine("AGREGAR UN VETERINARIOS");

            Console.SetCursorPosition(10, 8); Console.WriteLine("ID: ");
            Console.SetCursorPosition(10, 9); Console.WriteLine("NOMBRES: ");
            Console.SetCursorPosition(10, 10); Console.WriteLine("TELEFONO: ");

            Console.SetCursorPosition(20, 8); veterinario.Id = int.Parse(Console.ReadLine());
            Console.SetCursorPosition(20, 9); veterinario.Nombres = (Console.ReadLine());
            Console.SetCursorPosition(20, 10); veterinario.telefono = (Console.ReadLine());

            var mensaje = servicio.Guardar(veterinario);
            Console.ReadKey();
        }
    }
}
