﻿using ENTITY;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class ServicioVeterinario : ICrudGenerico<Veterinario>
    {
        List<Veterinario> veterinarios;

        public ServicioVeterinario ()
        {
            veterinarios = new List<Veterinario> ();
        }
        public List<Veterinario> Consultar()
        {
            return veterinarios;
        }

        public string Guardar(Veterinario entity)
        {
            try
            {
                //Validacion de datos
                if (entity == null)
                {
                    return "El veterinario no puede ser nulo";
                }
                veterinarios.Add(entity);
                return $"Se ha adicionado el veterianrio {entity.Nombres}";
            }
            catch (Exception)
            {

                return "Ha ocurrido un error al guardar el veterinario";
            }
        }
    }
}
