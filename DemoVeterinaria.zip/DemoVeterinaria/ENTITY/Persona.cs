﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITY
{
    public class Persona
    {
        public int Id { get; set; }
        public string Nombres { get; set; }
        public string telefono { get; set; }
    }
}
